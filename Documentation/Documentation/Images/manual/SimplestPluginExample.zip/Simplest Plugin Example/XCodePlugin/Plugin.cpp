/*
	This is a simple plugin, a bunch of functions that do simple things.
*/

#include "Plugin.pch"


const char* PrintHello(){
	return "Hello\0";
}

int PrintANumber(){
	return 5;
}

int AddTwoIntegers(int a, int b) {
	return a + b;
}

float AddTwoFloats(float a, float b) {
	return a + b;
}



